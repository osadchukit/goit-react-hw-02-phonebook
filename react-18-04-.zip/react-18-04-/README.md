# react-18

- Два слова про render и commit фазы (почему логи в методе render 2 раза идут)
- Паттерн controlled element
- Создаем форму регистрации
- Генерация Id элементов формы
- Множественные радио
- Множественные чекбоксы.
  - [Как делать не надо 1](https://medium.com/@wlodarczyk_j/handling-multiple-checkboxes-in-react-js-337863fd284e)
  - [Как делать не надо 2](https://www.nicesnippets.com/blog/react-js-get-multiple-checkbox-value-on-submit)
    https://stackblitz.com/edit/react-multiple-checkbox
  - [Как делать надо](http://react.tips/checkboxes-in-react-16/)
- Рассказать про
  [SASS_PATH](https://create-react-app.dev/docs/adding-a-sass-stylesheet)
- Коллекция заметок: добавление, обновление и фильтрация
- Рассказать про [classnames](https://github.com/JedWatson/classnames) ( пример
  в колорпикере и выполненное туду)


