import React from 'react';
import './Container.css';

export const Containers = ({ children }) => (
  <div className="Container">{children}</div>
);
